# **[OpenSpeedTest™️](https://openspeedtest.com)** -  Pure HTML5 Network Performance Estimation Tool.
## Helm3 Chart for **[OpenSpeedTest](https://openspeedtest.com)**

````
helm repo add speedtest https://openspeedtest.github.io/helm3-chart/
````

````
helm install my-openspeedtest speedtest/openspeedtest --version 0.1.0
````
